# Dataset_sample_proj > 2023-01-12 12:50am
https://universe.roboflow.com/classification/dataset_sample_proj

Provided by a Roboflow user
License: CC BY 4.0

